// Image slider

var swiper = new Swiper(".bg-thumb", {
  loop: true,
  spaceBetween: 10,
  slidesPerView: 4,
  freeMode: true,
  watchSlidesProgress: true,
});

var swiper2 = new Swiper(".bg-slider", {
  loop: true,
  spaceBetween: 0,
  thumbs: {
    swiper: swiper,
  },
});

// Sticky navbar  - scroll up

const body = document.body;
let lastScroll = 0;

window.addEventListener('scroll', () => {
  const currentScroll = window.pageYOffset

  if(currentScroll <= 0){
    body.classList.remove("scroll-up")
  }

  if(currentScroll > lastScroll && !body.classList.contains("scroll-down")){
    body.classList.remove("scroll-up")
    body.classList.add("scroll-down")
  }

  if(currentScroll < lastScroll && body.classList.contains("scroll-down")){
    body.classList.remove("scroll-down")
    body.classList.add("scroll-up")
  }

  lastScroll = currentScroll;
})

// Responsive

const bar = document.getElementsByClassName('nav-icons')[0]
const nav = document.getElementsByClassName('nav-menu')[0]

bar.addEventListener('click', () => {
  nav.classList.toggle('active')
})

const close = document.getElementsByClassName('close')[0]

close.addEventListener('click', () => {
    nav.classList.remove('active')
})

// Hamburger
const menuBtn = document.querySelector('.menu-btn');
let menuOpen = false;
menuBtn.addEventListener('click', () => {
  if(!menuOpen) {
    menuBtn.classList.add('open');
    menuOpen = true;
  } else {
    menuBtn.classList.remove('open');
    menuOpen = false;
  }
});
